<?php
session_start();
if(!isset($usernow))
{
  //  header('Location:../index.php');
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	
	<title>PHP Quiz</title>
	
	<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<body>

	<div id="page-wrap">

        <h1>Depression Test</h1>
		<h2>Over the last 2 weeks, how often have you been bothered by any of the following problems?

Please note, all fields are required.</h2>
<a href = "logout.php?signOut=1" style="height: 20px;width: 80px;position: absolute;background: green;color: white"></a>
		
		<form  method="post" id="quiz">
		
            <ol>
            
                <li>
                
                    <h3>A) Little interest or pleasure in doing things </h3>
                    
                    <div>
                        <input type="radio" name="question-1-answers" id="question-1-answers-A" value="A" required />
                        <label for="question-1-answers-A">A) Not at all </label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-1-answers" id="question-1-answers-B" value="B"  />
                        <label for="question-1-answers-B">B)Several Days</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-1-answers" id="question-1-answers-C" value="C" />
                        <label for="question-1-answers-C">C) More than Half the Days</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-1-answers" id="question-1-answers-D" value="D"/>
                        <label for="question-1-answers-D">D) Nearly Every Date</label>
                    </div>
                
                </li>
                
                <li>
                
                    <h3>2. Feeling down, depressed, or hopeless</h3>
                     <div>
                        <input type="radio" name="question-2-answers" id="question-1-answers-A" value="A" required/>
                        <label for="question-1-answers-A">A) Not at all </label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-2-answers" id="question-1-answers-B" value="B"/>
                        <label for="question-1-answers-B">B)Several Days</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-2-answers" id="question-1-answers-C" value="C" />
                        <label for="question-1-answers-C">C) More than Half the Days</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-2-answers" id="question-1-answers-D" value="D" />
                        <label for="question-5-answers-D">D) Nearly Every Date</label>
                    </div>
                
                </li>
                
                <li>
                
                    <h3>3. Trouble falling or staying asleep, or sleeping too much</h3>
                    
                    <div>
                        <input type="radio" name="question-3-answers" id="question-1-answers-A" value="A" required/>
                        <label for="question-1-answers-A">A) Not at all </label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-3-answers" id="question-1-answers-B" value="B" />
                        <label for="question-1-answers-B">B)Several Days</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-3-answers" id="question-1-answers-C" value="C" />
                        <label for="question-1-answers-C">C) More than Half the Days</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-3-answers" id="question-1-answers-D" value="D" />
                        <label for="question-5-answers-D">D) Nearly Every Date</label>
                    </div>
                
                </li>
                
                <li>
                
                    <h3>4. Feeling tired or having little energy</h3>
                    
                     <div>
                        <input type="radio" name="question-4-answers" id="question-1-answers-A" value="A" required />
                        <label for="question-1-answers-A">A) Not at all </label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-4-answers" id="question-1-answers-B" value="B" />
                        <label for="question-1-answers-B">B)Several Days</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-4-answers" id="question-1-answers-C" value="C" />
                        <label for="question-1-answers-C">C) More than Half the Days</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-4-answers" id="question-1-answers-D" value="D" />
                        <label for="question-5-answers-D">D) Nearly Every Date</label>
                    </div>
                
                </li>
                
                <li>
                
                    <h3>5. Poor appetite or overeating</h3>
                    
                   <div>
                        <input type="radio" name="question-5-answers" id="question-1-answers-A" value="A"  required/>
                        <label for="question-1-answers-A">A) Not at all </label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-5-answers" id="question-1-answers-B" value="B" />
                        <label for="question-1-answers-B">B)Several Days</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-5-answers" id="question-1-answers-C" value="C" />
                        <label for="question-1-answers-C">C) More than Half the Days</label>
                    </div>
                    
                    <div>
                        <input type="radio" name="question-5-answers" id="question-1-answers-D" value="D" />
                        <label for="question-5-answers-D">D) Nearly Every Date</label>
                    </div>
                
                </li>
            
            </ol>
            
            <input type="submit" value="submit" name = "submit"/>
		
		</form>
	
	</div>
    <?php
         

         if(isset($_POST['submit']))
        {
            echo("executing.....");
         $answer1 = $_POST['question-1-answers'];
            $answer2 = $_POST['question-2-answers'];
            $answer3 = $_POST['question-3-answers'];
            $answer4 = $_POST['question-4-answers'];
            $answer5 = $_POST['question-5-answers'];
        
            $totalCorrect = 0;
            
            if ($answer1 == "A") { $totalCorrect = $totalCorrect + 4; }
            if ($answer1 == "B") { $totalCorrect = $totalCorrect + 3; }
            if ($answer1 == "C") { $totalCorrect = $totalCorrect + 2; }
            if ($answer1 == "D") { $totalCorrect = $totalCorrect + 1; }

            if ($answer2 == "A") { $totalCorrect = $totalCorrect + 4; }
            if ($answer2 == "B") { $totalCorrect = $totalCorrect + 3; }
            if ($answer2 == "C") { $totalCorrect = $totalCorrect + 2; }
            if ($answer2 == "D") { $totalCorrect = $totalCorrect + 1 ;}

            if ($answer3 == "A") { $totalCorrect = $totalCorrect + 4; }
            if ($answer3 == "B") { $totalCorrect = $totalCorrect + 3; }
            if ($answer3 == "C") { $totalCorrect = $totalCorrect + 2; }
            if ($answer3 == "D") { $totalCorrect = $totalCorrect + 1 ;}

            if ($answer4 == "A") { $totalCorrect = $totalCorrect + 4; }
            if ($answer4 == "B") { $totalCorrect = $totalCorrect + 3; }
            if ($answer4 == "C") { $totalCorrect = $totalCorrect + 2; }
            if ($answer4 == "D") { $totalCorrect = $totalCorrect + 1 ;}

            if ($answer5 == "A") { $totalCorrect = $totalCorrect + 4; }
            if ($answer5 == "B") { $totalCorrect = $totalCorrect + 3; }
            if ($answer5 == "C") { $totalCorrect = $totalCorrect + 2; }
            if ($answer5 == "D") { $totalCorrect = $totalCorrect + 1; }

             $res = ($totalCorrect/4.0)*2;
             if($res <= 6)
             {}
            
            
         }




    ?>

	<script type="text/javascript">
	var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
	document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
	</script>
	<script type="text/javascript">
	var pageTracker = _gat._getTracker("UA-68528-29");
	pageTracker._initData();
	pageTracker._trackPageview();
	</script>

</body>

</html>