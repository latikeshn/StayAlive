window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title:{
		text: "Sucide Rate",
		horizontalAlign: "center"
	},
	data: [{
		type: "doughnut",
		startAngle: 60,
		//innerRadius: 60,
		indexLabelFontSize: 17,
		indexLabel: "{label} - #percent%",
		toolTipContent: "<b>{label}:</b> {y} (#percent%)",
		dataPoints: [
			{ y: 12, label: "2011" },
			{ y: 28, label: "2012" },
			{ y: 35, label: "2013" },
			{ y: 37, label: "2014"},
			{ y: 42, label: "2015"},
			{ y: 43.5, label: "2016"},
			{ y: 45, label: "2017"}
		]
	}]
});
chart.render();

}