<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Stay Alive</title>
     <link rel="stylesheet" href="css/style.css" type="text/css">
  <script src="js/main.js" type="text/javascript"></script>
<style type="text/css">
    body{
        
        background-image:  url("css/suicide4.jpg");
           
            background-attachment: fixed;
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
             
    }
    body::before{
        content: '';
        position: absolute;
        width: 100%;
        height: 133vh;
        background-color: black;
        opacity: 0.78;
    }
    .para{
        position: absolute;
        top:20%;
        color: white;
    }
    .para h1{
        vertical-align:middle;
        font-size: 350%;
        position: relative;
        top: 30%;
        left: 45%;
    }
    p{
       text-align: left;
        text-indent: 20px;
        padding: 10px;
        padding-left: 20px;
        border-left:  9px solid #F64740;
        margin-left: 30px;
        padding-left: 45px;
        font-size: 150%;
        
    }
   
    </style>
</head>
<body>
  <header><div id="container">
    <nav>
     
        </nav>
</div></header>
    <div class="para" style = "z-index: 100000"><h1>ABOUT US</h1>
    <hr><p>AASRA - Suicide Prevention Organisation is the world’s first publicly distributed standardized screening and response planning Community that empowers you with the professional skills needed to help someone in time of need from anywhere in the India.

 

With various facts and step-by-step procedures, AASRA provides best quitionaries to idetifies depressed, self-harm and suicide.
        </p>
<p> 

And also, helps you based on general safety answers you receive. To add to your support AASRA also populates an individualized response plan to assist in providing appropriate and effective support to another person in need.

 


 

One of the most advanced and innovative parts is the assessment report that is provided at the end of the guided walkthrough; this detailed information about risk and protective factors can be used to provide critical information to anyone capable of administering ongoing support.
        </p>
 <p>

The future of suicide prevention is when everyone is empowered with the necessary skills needed to ask the right questions about self-harm and suicide, and the ability to provide support in a moment’s notice.

        </p>
<p>
AASRA truly is the world's leading innovation for suicide prevention.

 

 
<br>
Don't wait until it's too late!
<br><br>
<b>HELPING PEOPLE IN DESPAIR</b>
</p></div>
</body>
</html>